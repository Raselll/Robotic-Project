# Projet-de-syst-me-embarqu-
Construction en équipe d'un système matériel et logiciel basé sur les microcontrôleurs ATMEGA324a et ATMEGA8 en utilisant la librairie &lt;avr/io.h> C++
